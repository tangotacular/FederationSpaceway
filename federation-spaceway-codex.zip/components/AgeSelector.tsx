import React from 'react';
import { AGES } from '../constants';
import { AgeType } from '../types';

interface AgeSelectorProps {
  selectedAge: AgeType | 'ALL';
  onSelect: (age: AgeType | 'ALL') => void;
}

const AgeSelector: React.FC<AgeSelectorProps> = ({ selectedAge, onSelect }) => {
  return (
    <div className="sticky top-0 z-40 bg-space-black/90 backdrop-blur-md border-b border-gray-800 py-4 mb-8 overflow-x-auto scrollbar-hide">
      <div className="flex space-x-4 px-4 min-w-max mx-auto max-w-7xl">
        <button
          onClick={() => onSelect('ALL')}
          className={`px-4 py-2 rounded-full font-orbitron text-sm transition-all duration-300 border 
            ${selectedAge === 'ALL' 
              ? 'bg-white text-space-black border-white shadow-[0_0_15px_rgba(255,255,255,0.3)]' 
              : 'bg-transparent text-gray-400 border-gray-800 hover:border-gray-500'}`}
        >
          FULL HISTORY
        </button>
        {AGES.map((age) => (
          <button
            key={age.id}
            onClick={() => onSelect(age.id)}
            className={`px-4 py-2 rounded-full font-orbitron text-sm transition-all duration-300 border whitespace-nowrap
              ${selectedAge === age.id 
                ? `bg-gray-800 border-gray-600 ${age.color} shadow-[0_0_10px_rgba(255,255,255,0.1)]` 
                : 'bg-transparent text-gray-500 border-gray-800 hover:border-gray-600'}`}
          >
            {age.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default AgeSelector;