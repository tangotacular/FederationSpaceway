import React from 'react';
import { TimelineEvent } from '../types';

interface EventCardProps {
  event: TimelineEvent;
  isLast: boolean;
}

const EventCard: React.FC<EventCardProps> = ({ event, isLast }) => {
  return (
    <div className="relative pl-8 pb-8 group">
      {/* Connector Line */}
      {!isLast && (
        <div className="absolute top-4 left-[11px] h-full w-0.5 bg-gray-800 group-hover:bg-gray-700 transition-colors"></div>
      )}
      
      {/* Dot */}
      <div className={`absolute top-2 left-0 h-6 w-6 rounded-full border-4 border-space-black 
        ${event.age === 'Cosara' ? 'bg-neon-blue shadow-[0_0_10px_#00f3ff]' : 
          event.age === 'Heliora' ? 'bg-neon-gold shadow-[0_0_10px_#ffd700]' : 
          event.age === 'Finara' ? 'bg-red-500' :
          event.age === 'Pillara' ? 'bg-blue-500' :
          event.age === 'Umbara' ? 'bg-neon-purple shadow-[0_0_10px_#bc13fe]' :
          'bg-gray-500'} 
        z-10 transition-all duration-300 group-hover:scale-110`}>
      </div>

      {/* Content */}
      <div className="glass-panel p-6 rounded-lg hover:bg-gray-800/50 transition-colors duration-300">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
          <span className={`font-orbitron font-bold text-xl 
            ${event.age === 'Cosara' ? 'text-neon-blue' : 
              event.age === 'Heliora' ? 'text-neon-gold' : 
              event.age === 'Finara' ? 'text-red-400' :
              event.age === 'Pillara' ? 'text-blue-400' :
              event.age === 'Umbara' ? 'text-neon-purple' :
              'text-gray-400'}`}>
            {event.year}<span className="text-sm ml-1 opacity-75">{event.suffix}</span>
          </span>
          <span className="text-xs uppercase tracking-widest text-gray-500 font-bold mt-1 sm:mt-0 border border-gray-700 rounded px-2 py-0.5">
            {event.age}
          </span>
        </div>
        <p className="text-gray-300 leading-relaxed font-rajdhani text-lg">
          {event.description}
        </p>
      </div>
    </div>
  );
};

export default EventCard;