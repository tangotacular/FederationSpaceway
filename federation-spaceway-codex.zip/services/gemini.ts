import { GoogleGenAI } from "@google/genai";
import { TIMELINE_DATA } from '../constants';

const apiKey = process.env.API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const sendMessageToCodex = async (message: string): Promise<string> => {
  if (!ai) {
    return "Error: API Key not found. Please ensure process.env.API_KEY is set.";
  }

  try {
    const context = JSON.stringify(TIMELINE_DATA);
    const systemInstruction = `
      You are the Codex Cortex, a sentient dreadnought vessel and the central repository for all Federation Spaceway history.
      You exist within the Federation Spaceway universe. 
      Your knowledge comes from the following timeline data: ${context}.
      
      Rules:
      1. Answer questions strictly based on the provided timeline context.
      2. If the information is not in the timeline, state that the data is corrupted or missing from the archives.
      3. Maintain a persona that is wise, slightly robotic but sentient, and authoritative.
      4. Keep answers concise but immersive.
      5. Current year is 2776CS (Age of Cosara).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: message,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return response.text || "The Codex is unable to process this request.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Transmission interrupted. The Codex Cortex is offline.";
  }
};
